let a = 'hello world!!!';
a += "자바" + '스크립트';
console.log(a);